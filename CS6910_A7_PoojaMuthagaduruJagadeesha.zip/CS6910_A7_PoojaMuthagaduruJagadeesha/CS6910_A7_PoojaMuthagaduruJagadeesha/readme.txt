Overview
	The MemBrain Card Game is a classic matching game implemented in Java using JavaFX. The objective of the game is to find and match 	pairs of cards. The game keeps track of the player's score and displays cards face-down until they are matched.

Features
	Card Matching: Flip cards to find matching pairs.
	Score Tracking: Increment score when a pair is successfully matched.
	UI: JavaFX-based graphical user interface with a grid of cards.

Project Structure
	MemBrainCodeBehind.java: The main JavaFX application class that initializes the game window and manages the game flow.
	GameController.java: The controller class that contains the game logic, such as card selection and matching.
	ViewCard.java: Represents individual cards in the game, including methods for flipping and matching cards.
	Card.java: Represents the card object with properties like card value.

Setup and Installation
Prerequisites:
	Java Development Kit (JDK) 8 or higher
	JavaFX SDK (if not included in the JDK)

Usage
	Start the Game: Run the application to open the game window.
	Flip Cards: Click on the cards to flip them and reveal their faces.
	Match Cards: Try to find matching pairs of cards.
	Score: Your score will increment each time you successfully match a pair.
	End Game: The game continues until all pairs are matched.
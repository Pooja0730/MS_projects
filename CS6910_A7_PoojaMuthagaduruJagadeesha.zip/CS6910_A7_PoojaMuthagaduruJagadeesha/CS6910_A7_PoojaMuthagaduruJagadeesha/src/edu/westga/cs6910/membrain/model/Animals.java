package edu.westga.cs6910.membrain.model;

/**
 * The Enum Animals.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * 
 * @version Summer 06/14/2024
 */
public enum Animals {
	PIGGY, 
	DUCKY,
	DOGGY,
	PUSSY,
	HORSEY, 
	HIPPO, 
	PANDA;
}

package edu.westga.cs6910.membrain.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class HumanPlayer.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024 06/23/2024
 */
public class HumanPlayer extends Player implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new human player.
	 *
	 * @param name the name
	 */
	public HumanPlayer(String name) {
        super(name);
    }

    /**
     * Select card.
     *
     * @param cardIndex the card index
     */
    @Override
    public void selectCard(int cardIndex) {
    	this.setLastSelectedCard(cardIndex);
        System.out.println(super.getName() + " selected card " + cardIndex);
    }

    /**
     * Flip card.
     *
     * @param cardIndex the card index
     */
    @Override
    public void flipCard(int cardIndex) {
    	this.setLastFlippedCard(cardIndex);
        System.out.println(super.getName() + " flipped card " + cardIndex);
    }

    /**
     * Checks for matched cards.
     *
     * @return true, if successful
     */
    @Override
    public boolean hasMatchedCards() {
        // Implement logic to check if the selected cards match
        return false;
    }
}

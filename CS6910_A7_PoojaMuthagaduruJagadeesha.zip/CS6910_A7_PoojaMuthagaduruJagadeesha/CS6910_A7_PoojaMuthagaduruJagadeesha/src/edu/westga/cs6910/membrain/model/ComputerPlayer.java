package edu.westga.cs6910.membrain.model;

import java.io.Serializable;
import java.util.Random;

/**
 * The Class ComputerPlayer.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024 06/23/2024
 */
public class ComputerPlayer extends Player implements Serializable {
	private static final long serialVersionUID = 1L;
	private Random random;

    /**
     * Instantiates a new computer player.
     *
     * @param name the name
     */
    public ComputerPlayer(String name) {
        super(name);
        this.random = new Random();
    }

    @Override
    public void selectCard(int cardIndex) {
    	this.setLastSelectedCard(cardIndex);
        System.out.println(super.getName() + " (computer) selected card " + cardIndex);
    }

    @Override
    public void flipCard(int cardIndex) {
    	this.setLastFlippedCard(cardIndex);
        System.out.println(super.getName() + " (computer) flipped card " + cardIndex);
    }

    @Override
    public boolean hasMatchedCards() {
        // Implement logic to check if the selected cards match
        return false;
    }

    /**
     * Make move.
     *
     * @param totalCards the total cards
     * @return the int
     */
    public int makeMove(int totalCards) {
        int cardIndex = this.random.nextInt(totalCards);
        this.selectCard(cardIndex);
        this.flipCard(cardIndex);
        return cardIndex;
    }
}

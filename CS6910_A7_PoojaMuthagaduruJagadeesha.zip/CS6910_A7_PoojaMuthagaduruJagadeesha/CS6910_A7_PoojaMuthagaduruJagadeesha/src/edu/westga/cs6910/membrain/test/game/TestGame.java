package edu.westga.cs6910.membrain.test.game;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs6910.membrain.game.Game;
import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.model.Player;

class TestGame {

	private Game game;
    private Player humanPlayer;
    private Player computerPlayer;

    @BeforeEach
    void setUp() {
        game = new Game("Pooja");
        humanPlayer = game.getHumanPlayer();
        computerPlayer = game.getComputerPlayer();
    }

    @Test
    void testInitialization() {
        assertNotNull(game.getDeck());
        assertEquals("Pooja", humanPlayer.getName());
        assertEquals("Computer", computerPlayer.getName());
    }

    @Test
    void testPlayTurnHumanPlayer() {
        game.playTurn(humanPlayer, 0); // Human selects first card
        assertEquals(0, humanPlayer.getLastSelectedCard());
        assertEquals(0, humanPlayer.getLastFlippedCard());

        game.playTurn(humanPlayer, 1); // Human selects second card
        assertEquals(1, humanPlayer.getLastSelectedCard());
        assertEquals(1, humanPlayer.getLastFlippedCard());
    }

    @Test
    void testPlayTurnComputerPlayer() {
        game.playTurn(computerPlayer, 2); // Computer selects first card
        assertEquals(2, computerPlayer.getLastSelectedCard());
        assertEquals(2, computerPlayer.getLastFlippedCard());

        game.playTurn(computerPlayer, 3); // Computer selects second card
        assertEquals(3, computerPlayer.getLastSelectedCard());
        assertEquals(3, computerPlayer.getLastFlippedCard());
    }

    @Test
    void testCheckForMatch() {
        game.getDeck().shuffle(); // Ensure deck is shuffled for randomness
        Card firstCard = game.getDeck().getCardDeck().get(0);
        Card secondCard = game.getDeck().getCardDeck().get(1);

        // Manually set the selected cards to test the match logic
        game.getSelectedCards().add(firstCard);
        game.getSelectedCards().add(secondCard);

        boolean match = game.checkForMatch();

        if (firstCard.getFace().equals(secondCard.getFace())) {
            assertTrue(match);
        } else {
            assertFalse(match);
        }
    }

    @Test
    void testGameFlow() {
        game.playGame();
        assertTrue(humanPlayer.getScore() >= 0);
        assertTrue(computerPlayer.getScore() >= 0);
    }
}

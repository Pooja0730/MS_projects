package edu.westga.cs6910.membrain.test.deck;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.jupiter.api.Test;

import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.model.Deck;

/**
 * Tests the Deck class AddCard
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 06/14/2024
 */
public class TestAddCard {

	@Test
	public void testToAddOneCardWithUnShuffledDeckofCards() {
		Deck testDeck = new Deck();

		Card dealtCard = testDeck.dealCard();
		assertFalse(testDeck.getCardDeck().contains(dealtCard));
		
		testDeck.addCard(dealtCard);
		assertTrue(testDeck.getCardDeck().contains(dealtCard));
	}
	
	@Test
	public void testToDealTwoCardsAndAddOneCardToTheDeck() {
		Deck testDeck = new Deck();

		Card dealtCard1 = testDeck.dealCard();
		Card dealtCard2 = testDeck.dealCard();
		
		assertFalse(testDeck.getCardDeck().contains(dealtCard1));
		assertFalse(testDeck.getCardDeck().contains(dealtCard2));
		
		testDeck.addCard(dealtCard1);
		assertTrue(testDeck.getCardDeck().contains(dealtCard1));
		assertFalse(testDeck.getCardDeck().contains(dealtCard2));
	}
}

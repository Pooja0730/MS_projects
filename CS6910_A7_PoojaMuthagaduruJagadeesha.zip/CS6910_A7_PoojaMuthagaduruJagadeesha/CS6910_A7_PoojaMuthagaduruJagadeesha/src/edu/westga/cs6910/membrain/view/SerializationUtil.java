package edu.westga.cs6910.membrain.view;

import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.stream.Collectors;

import edu.westga.cs6910.membrain.model.Card;

/**
 * The Class SerializationUtil.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024
 */
public class SerializationUtil {

    /**
     * Serialize list property.
     *
     * @param listProperty the list property
     * @param filePath the file path
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void serializeListProperty(ListProperty<Card> listProperty, String filePath) throws IOException {
        List<Card> cardList = listProperty.get();
        //return cardList;
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(cardList);
        }
        
    }
    
    /**
     * Deserialize list property.
     *
     * @param filePath the file path
     * @return the list property
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ClassNotFoundException the class not found exception
     */
    @SuppressWarnings("unchecked")
	public static ListProperty<Card> deserializeListProperty(String filePath) throws IOException, ClassNotFoundException {
        List<Card> cardList;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            cardList = (List<Card>) ois.readObject();
        }
        return new SimpleListProperty<>(FXCollections.observableArrayList(cardList));
    }

    /**
     * Serialize object property.
     *
     * @param objectProperty the object property
     * @param filePath the file path
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void serializeObjectProperty(ObjectProperty<Card> objectProperty, String filePath) throws IOException {
        Card card = objectProperty.get();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(card);
        }
    }

    /**
     * Deserialize object property.
     *
     * @param filePath the file path
     * @return the object property
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ClassNotFoundException the class not found exception
     */
    public static ObjectProperty<Card> deserializeObjectProperty(String filePath) throws IOException, ClassNotFoundException {
        Card card;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            card = (Card) ois.readObject();
        }
        return new SimpleObjectProperty<>(card);
    }
    
    /**
     * Convert list property to list.
     *
     * @param listProperty the list property
     * @return the list
     */
    public static List<Card> convertListPropertyToList(ListProperty<Card> listProperty) {
        return listProperty.stream().collect(Collectors.toList());
    }
    
    /**
     * Convert object property to object.
     *
     * @param objectProperty the object property
     * @return the card
     */
    public static Card convertObjectPropertyToObject(ObjectProperty<Card> objectProperty) {
        return objectProperty.get();
    }
    
    /**
     * Convert list to list property.
     *
     * @param list the list
     * @return the list property
     */
    public static ListProperty<Card> convertListToListProperty(List<Card> list) {
        return new SimpleListProperty<>(FXCollections.observableArrayList(list));
    }
    
    /**
     * Convert object to object property.
     *
     * @param card the card
     * @return the object property
     */
    public static ObjectProperty<Card> convertObjectToObjectProperty(Card card) {
        return new SimpleObjectProperty<>(card);
    }
}
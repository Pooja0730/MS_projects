package edu.westga.cs6910.membrain.view;

import java.io.IOException;
import java.util.ArrayList;

import edu.westga.cs6910.membrain.game.SaveData;
//import edu.westga.cs6910.membrain.game.Game;
import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.viewmodel.ViewCard;
import edu.westga.cs6910.membrain.viewmodel.ViewModel;
import javafx.animation.Timeline;
//import javafx.animation.PauseTransition;
import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;

/**
 * The Class MemBrainCodeBehind.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024
 */
public class MemBrainCodeBehind {
	private static final Color MEMBRAIN_TABLE_BACKGROUND = Color.GREEN.deriveColor(1, 1, 1, 0.8);

	private ViewCard viewCard;
	private ViewModel viewModel;
	private ArrayList<Card> guessedCard;

	@FXML
	private AnchorPane pane;

	@FXML
	private HBox playerBox;

	@FXML
	private Button restartGameButton;

	@FXML
	private Button nextLevelButton;

	@FXML
	private Label numberOfGuesses;

	@FXML
	private Label score;

	@FXML
	private MenuItem saveGame;

	@FXML
	private MenuItem loadGame;

	@FXML
	private MenuItem moreInfo;

	@FXML
	private MenuItem about;

	private ObjectProperty<Card> selectedFirstCardObjectProperty;
	private ObjectProperty<Card> selectedSecondCardObjectProperty;
	private ListProperty<Card> duplicateCardList;
	private ViewCard firstViewCard = null;
	private ViewCard secondViewCard = null;

	private int guesses;
	private int scores;
	private int cardCount;
	private boolean checkFlag = false;
	private int firstIndex = 0;
	private int secondIndex = 0;
	private Card firstCard = null;
	private Card secondCard = null;

	/**
	 * Instantiates a new casino-code-behind.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public MemBrainCodeBehind() {
		this.viewModel = new ViewModel();
		this.viewCard = new ViewCard();
		this.selectedFirstCardObjectProperty = new SimpleObjectProperty<Card>();
		this.selectedSecondCardObjectProperty = new SimpleObjectProperty<Card>();
		this.duplicateCardList = this.viewModel.playerHandProperty();
		this.guessedCard = new ArrayList<Card>();
		this.cardCount = 2;
	}

	/**
	 * Initializes the GUI components, binding them to the view model properties.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	@FXML
	public void initialize() {
		this.initializeUI();
		this.bindToViewModel();
		this.setUpEventHandlers();
		this.setUpListeners();
		this.viewModel.startGame(this.cardCount);
	}

	private void initializeUI() {
		BackgroundFill fill = new BackgroundFill(MEMBRAIN_TABLE_BACKGROUND, CornerRadii.EMPTY, Insets.EMPTY);
		Background background = new Background(fill);
		this.pane.setBackground(background);
	}

	private void bindToViewModel() {

		this.viewModel.playerHandProperty().addListener((ListChangeListener<Card>) change -> {
			this.refreshPlayerBox();
		});

		this.selectedFirstCardObjectProperty.bindBidirectional(this.viewModel.selectedFirstCardObjectProperty());
		this.selectedSecondCardObjectProperty.bindBidirectional(this.viewModel.selectedSecondCardObjectProperty());
	}

	private void setUpEventHandlers() {
		this.restartGameButton.setOnAction(event -> {
			this.bindToViewModel();
			this.setUpEventHandlers();
			this.setUpListeners();
			this.viewModel.startGame(this.cardCount);
			this.resetGame();
		});
		this.nextLevelButton.setOnAction(event -> {
			this.cardCount += 1;
			this.viewModel.startGame(this.cardCount);
			this.nextLevel();
		});
		this.saveGame.setOnAction(event -> {
			this.saveGame();
		});
		this.loadGame.setOnAction(event -> {
			this.loadGame();
			this.refreshPlayerBox();
		});
		this.moreInfo.setOnAction(event -> {
			this.getMoreInfoAboutMemBrain();
		});
		this.about.setOnAction(event -> {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("About");
			alert.setHeaderText("07/19/2024\nPooja Muthagaduru Jagadeesha");
			alert.showAndWait();
		});
	}

	private void loadGame() {
		try {
			Object[] gameState = MemBrainSerializer.deserialize();
			SaveData data = (SaveData) gameState[0];
			this.viewModel.playerHandProperty()
					.set(SerializationUtil.convertListToListProperty(data.getCardList()));
			this.selectedFirstCardObjectProperty
					.set(SerializationUtil.convertObjectToObjectProperty(data.getFirstCard()).get());
			this.selectedSecondCardObjectProperty
					.set(SerializationUtil.convertObjectToObjectProperty(data.getSecondCard()).get());
			this.guesses = data.getNumberOfGuesses();
			this.numberOfGuesses.textProperty().set(String.valueOf(this.guesses));
			this.scores = data.getScore();
			this.score.textProperty().set(String.valueOf(this.scores));
			this.viewCard = data.getCardView();
		} catch (ClassNotFoundException | IOException exception) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("MemBrain Card Game");
			alert.setHeaderText("Game could not be loaded from file system.");
			alert.setContentText(exception.getMessage());
			alert.showAndWait();
		}
	}

	private void saveGame() {
		SaveData data = new SaveData();
		data.setCardList(SerializationUtil.convertListPropertyToList(this.viewModel.playerHandProperty()));
		data.setFirstCard(SerializationUtil.convertObjectPropertyToObject(this.selectedFirstCardObjectProperty));
		data.setSecondCard(SerializationUtil.convertObjectPropertyToObject(this.selectedSecondCardObjectProperty));
		data.setNumberOfGuesses(this.guesses);
		data.setScore(this.scores);
		data.setCardView(this.viewCard);
		try {
			MemBrainSerializer.serialize(new Object[] { data });
		} catch (Exception ex) {
			System.out.println("Couldn't save game state: " + ex.getMessage());
			ex.printStackTrace();
		}
	}

	private void getMoreInfoAboutMemBrain() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setWidth(100);
		alert.setTitle("More info about the game");
		alert.setHeaderText("Rules of the game");
		
		String objective = "Objective: \nMatch all pairs of cards on the game board to complete the level.\n";

		String setup = "\nGame Setup: \nGame Board: The game board consists of a grid of face-down cards.\r\n"
				+ "Cards: Each card has a matching pair hidden among the other cards.\n";

		String howToPlay = "\nHow To Play: \nFlip a Card: Click on any face-down card to flip it and reveal the image or symbol on the other side.\r\n"
				+ "Flip Another Card: Click on another face-down card.\r\n"
				+ "Match: If the two clicked cards match, they will be disappeared from the lot and you score a point.\r\n"
				+ "Mismatch: If the two clicked cards do not match, they will be flipped back face-down and the number of guesses you took will be increased everytime you click a card.\r\n"
				+ "Continue: Continue flipping two cards at a time, trying to remember the positions and images of the cards to make matching pairs.\n";

		String levels = "\nLevels: \nLevel Progression: The game consists of multiple levels. Each level increases in difficulty by adding more cards to the game board.\r\n"
				+ "Next Level: Once all pairs are matched, the game will advance to the next level when you manually click the \"Next Level\" button.\n";

		String features = "\nGame Features: \nRestart Game: If you want to start the current level over, click the \"Restart game\" button. This will reset the game board for the current level.\r\n"
				+ "Save Game: To save your progress and continue later, go to \"File\" in the menubar, and click the \"Save Game\" option. This will save the current game state, including the level, card positions, matched pairs, the number of guesses taken when saving the game and the current score.\r\n"
				+ "Load Game: To load a previously saved game, go to \"File\" in the menubar, and click the \"Load Game\" option. This will restore the saved game state and allow you to continue from where you left off.\n";

		String tips = "\nTips for Success: \nMemory Skills: Pay close attention to the positions and images of the cards you flip.\r\n"
				+ "Pattern Recognition: Look for patterns and use logic to deduce the positions of matching cards.\r\n"
				+ "Practice: The more you play, the better your memory and concentration will become.\n";

		alert.setContentText(objective + setup + howToPlay + levels + features + tips);
		
		DialogPane dialogPane = alert.getDialogPane();
		dialogPane.setPrefSize(600, 740);
		
		alert.showAndWait();
	}

	private void setUpListeners() {
		this.selectedFirstCardObjectProperty.addListener((observable, oldValue, newValue) -> {
			if (newValue != null && newValue != oldValue) {
				this.selectedFirstCardObjectProperty.set(newValue);
			}
		});

		this.selectedSecondCardObjectProperty.addListener((observable, oldValue, newValue) -> {
			if (newValue != null && newValue != oldValue) {
				this.selectedSecondCardObjectProperty.set(newValue);
			}
		});
	}

	private void refreshPlayerBox() {
		this.playerBox.getChildren().clear();
		this.duplicateCardList = this.viewModel.playerHandProperty();

		for (int index = 0; index < this.duplicateCardList.size(); index++) {
			int val = index;
			Card card = this.viewModel.playerHandProperty().get(index);
			this.viewCard = new ViewCard(card);
			Node cardNode = this.viewCard.getView();
			if (this.selectedFirstCardObjectProperty.get() == null
					&& this.selectedSecondCardObjectProperty.get() == null) {
				cardNode = this.viewCard.faceDown(card);
			} else if (this.firstIndex == val && card.equals(this.selectedFirstCardObjectProperty.get())) {
				cardNode = this.viewCard.faceUp(card);
			} else if (this.secondIndex == val && card.equals(this.selectedSecondCardObjectProperty.get())) {
				cardNode = this.viewCard.faceUp(card);
			} else if (card.equals(this.selectedFirstCardObjectProperty.get())
					|| card.equals(this.selectedSecondCardObjectProperty.get())) {
				cardNode = this.viewCard.faceDown(card);
			} else if (card.equals(this.selectedFirstCardObjectProperty.get())
					&& card.equals(this.selectedSecondCardObjectProperty.get())) {
				cardNode = this.viewCard.faceDown(card);
			} else if (!card.equals(this.selectedFirstCardObjectProperty.get())
					&& !card.equals(this.selectedSecondCardObjectProperty.get())) {
				cardNode = this.viewCard.faceDown(card);
			} else {
				cardNode = this.viewCard.faceUp(card);
			}
			cardNode.setOnMouseClicked(event -> {
				this.handleCardClick(card, val);
				Timeline timeline = new Timeline(2500);
				timeline.pause();
				timeline.play();
			});

			this.playerBox.getChildren().add(cardNode);
		}
	}

	private void updateScore() {
		if (this.guessedCard.get(0).equals(this.guessedCard.get(1))) {
			this.scores = Integer.parseInt(this.score.getText());
			this.scores++;
			this.score.textProperty().set(String.valueOf(this.scores));
		}
	}

	private void resetGame() {
		this.guesses = 0;
		this.scores = 0;
		this.guessedCard.clear();
		this.numberOfGuesses.textProperty().set(String.valueOf(this.guesses));
		this.score.textProperty().set(String.valueOf(this.scores));
	}

	private void nextLevel() {
		this.guesses = 0;
		this.guessedCard.clear();
		this.numberOfGuesses.textProperty().set(String.valueOf(this.guesses));
		this.score.textProperty().set(String.valueOf(this.scores));
	}

	private void handleCardClick(Card card, int index) {
		this.guesses++;
		this.numberOfGuesses.textProperty().set(String.valueOf(this.guesses));

		if (this.firstViewCard == null) {
			this.firstCardSetup(card, index);
		} else if (this.secondViewCard == null) {
			this.secondCardSetup(card, index);
			if (this.guessedCard.size() == 2) {
				this.compareCards();
			}
			this.resetCardSelection();
		}
	}

	private void firstCardSetup(Card card, int index) {
		this.firstViewCard = new ViewCard(card);
		this.firstIndex = index;
		this.firstCard = card;
		this.selectedFirstCardObjectProperty.set(this.firstCard);
		this.updatePlayerBox(index, this.firstViewCard.faceUp(this.firstCard));
		this.guessedCard.add(this.firstCard);
	}

	private void secondCardSetup(Card card, int index) {
		this.secondViewCard = new ViewCard(card);
		this.secondIndex = index;
		this.secondCard = card;
		this.selectedSecondCardObjectProperty.set(this.secondCard);
		this.updatePlayerBox(index, this.secondViewCard.faceUp(this.secondCard));
		this.guessedCard.add(this.secondCard);
	}

	private void updatePlayerBox(int index, Node cardNode) {
		this.playerBox.getChildren().remove(index);
		this.playerBox.getChildren().add(index, cardNode);
	}

	private void resetCardSelection() {
		this.firstCard = null;
		this.secondCard = null;
		this.firstViewCard = null;
		this.secondViewCard = null;
		this.firstIndex = 0;
		this.secondIndex = 0;
	}

	private void compareCards() {
		if (this.cardsMatch(this.firstViewCard.getCard(), this.secondViewCard.getCard())) {
			this.updateScore();
			this.removeMatchedCards();
		} else {
			this.flipBackCards();
		}
		this.guessedCard.clear();
		this.selectedFirstCardObjectProperty.set(null);
		this.selectedSecondCardObjectProperty.set(null);
		this.refreshPlayerBox();
	}

	private boolean cardsMatch(Card firstCard, Card secondCard) {
		return firstCard.getSuit().equals(secondCard.getSuit()) && firstCard.getRank() == secondCard.getRank();
	}

	private void removeMatchedCards() {
		this.duplicateCardList.remove(this.firstIndex);
		if (this.secondIndex < this.firstIndex) {
			this.duplicateCardList.remove(this.secondIndex);
		} else {
			this.duplicateCardList.remove(this.secondIndex - 1);
		}
	}

	private void flipBackCards() {
		if (this.checkFlag && this.firstIndex != this.secondIndex) {
			this.updatePlayerBox(this.firstIndex, this.firstViewCard.faceDown(this.firstCard));
			this.updatePlayerBox(this.secondIndex, this.secondViewCard.faceDown(this.secondCard));
		}
	}
}

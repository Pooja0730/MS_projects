package edu.westga.cs6910.membrain.test.deck;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.model.Deck;

/**
 * Tests the Deck class DealCard
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 06/14/2024
 */
public class TestDealCard {

	@Test
	public void testToDeal1CardWithUnShuffledDeckofCards() {
		Deck testDeck = new Deck();
		int deckSize = testDeck.getCardDeck().size();
		
		String expectedCard = testDeck.getCardDeck().get(deckSize - 1).getRank() + " of " + testDeck.getCardDeck().get(deckSize - 1).getSuit();
		Card dealtCard = testDeck.dealCard();
		String actualCard = dealtCard.getRank() + " of " + dealtCard.getSuit();
		
		assertEquals(expectedCard, actualCard);
		assertEquals(51, testDeck.getCardDeck().size());
	}
	
	@Test
	public void testToDeal1CardWithShuffledDeckofCards() {
		Deck testDeck = new Deck();
		int deckSize = testDeck.getCardDeck().size();
		testDeck.shuffle();
		
		String expectedCard = testDeck.getCardDeck().get(deckSize - 1).getRank() + " of " + testDeck.getCardDeck().get(deckSize - 1).getSuit();
		Card dealtCard = testDeck.dealCard();
		String actualCard = dealtCard.getRank() + " of " + dealtCard.getSuit();
		
		assertEquals(expectedCard, actualCard);
		assertEquals(51, testDeck.getCardDeck().size());
	}
	
	@Test
	public void testToDealAllCardsWithUnShuffledDeckofCards() {
		Deck testDeck = new Deck();
		int deckSize = testDeck.getCardDeck().size();
		
		for (int index = 0; index < deckSize; index++) {
			testDeck.dealCard();
		}
		int expectedDeckSize = 0;
		
		assertEquals(expectedDeckSize, testDeck.getCardDeck().size());
	}
}
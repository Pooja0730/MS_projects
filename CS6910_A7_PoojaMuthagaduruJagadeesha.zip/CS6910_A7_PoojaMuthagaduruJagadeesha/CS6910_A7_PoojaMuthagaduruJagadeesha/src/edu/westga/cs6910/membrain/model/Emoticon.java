package edu.westga.cs6910.membrain.model;

/**
 * The Enum Emoticon.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * 
 * @version Summer 06/14/2024
 */
public enum Emoticon {
	ANGRY, 
	AFRAID,
	ANNOYED,
	HAPPY,
	BORED, 
	CONFUSED, 
	SAD;
}

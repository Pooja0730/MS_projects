package edu.westga.cs6910.membrain.viewmodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.model.Deck;
import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;

/**
 * The class ViewModel.
 * 
 * @author CS6910
 * @version Summer 2024
 */
public class ViewModel implements Serializable {
	private static final long serialVersionUID = 1L;

	private Deck deck;

	private ArrayList<Card> dealtHand = new ArrayList<Card>();

	private ListProperty<Card> playerHandProperty;

	private ObjectProperty<Card> selectedFirstCardProperty;
	private ObjectProperty<Card> selectedSecondCardProperty;

	/**
	 * Instantiates a new view model
	 */
	public ViewModel() {
		this.deck = new Deck();
		this.deck.shuffle();

		this.playerHandProperty = new SimpleListProperty<Card>(FXCollections.observableArrayList(this.dealtHand));
		this.selectedFirstCardProperty = new SimpleObjectProperty<Card>();
		this.selectedSecondCardProperty = new SimpleObjectProperty<Card>();
	}

	/**
	 * This method should be refactored to use the Game object, and the Game object
	 * can then reference the Deck object.
	 * 
	 * @param cardCount count of cards for each level
	 */
	public void startGame(int cardCount) {
		this.dealtHand = new ArrayList<Card>();
		try {
			for (int count = 0; count < cardCount; count++) {
				Card card = this.deck.dealCard();
				Card cardDuplicate = (Card) card.clone();
				this.dealtHand.add(card);
				this.dealtHand.add(cardDuplicate);
			}
		} catch (Exception ex) {
			System.err.println(ex.getMessage());
		}
		Collections.shuffle(this.dealtHand);
		this.playerHandProperty.setAll(this.dealtHand);
	}

	/**
	 * Gets the player hand property.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the player hand property
	 */
	public ListProperty<Card> playerHandProperty() {
		return this.playerHandProperty;
	}

	/**
	 * Gets the selected first card property.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return selected card property
	 */
	public ObjectProperty<Card> selectedFirstCardObjectProperty() {
		return this.selectedFirstCardProperty;
	}

	/**
	 * Gets the selected second card object property.
	 *
	 * @precondition none
	 * @postcondition none
	 * @return selected card property
	 */
	public ObjectProperty<Card> selectedSecondCardObjectProperty() {
		return this.selectedSecondCardProperty;
	}
}

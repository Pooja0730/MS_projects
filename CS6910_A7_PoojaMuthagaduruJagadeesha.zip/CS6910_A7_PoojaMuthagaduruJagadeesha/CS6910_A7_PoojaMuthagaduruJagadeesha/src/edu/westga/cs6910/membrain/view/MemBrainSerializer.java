package edu.westga.cs6910.membrain.view;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * The Class MemBrainSerializer.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024
 */
public final class MemBrainSerializer {
	private static final String DATA_PATH = "game_state.ser";

	private MemBrainSerializer() {

	}

	/**
	 * Serialize.
	 *
	 * @param memBrainGame the mem brain game
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void serialize(Object[] memBrainGame) throws IOException {
        try (var serializer = new ObjectOutputStream(new FileOutputStream(DATA_PATH))) {
            serializer.writeObject(memBrainGame);
        }
    }

	/**
	 * Deserialize.
	 *
	 * @return the object[]
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ClassNotFoundException the class not found exception
	 */
	public static Object[] deserialize() throws IOException, ClassNotFoundException {
        try (var deserializer = new ObjectInputStream(new FileInputStream(DATA_PATH))) {
            return (Object[]) deserializer.readObject();
        }
    }
	
	/**
	 * Save.
	 *
	 * @param data the data
	 * @param fileName the file name
	 * @throws Exception the exception
	 */
	public static void save(Serializable data, String fileName) throws Exception {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(data);
        }
    }
}

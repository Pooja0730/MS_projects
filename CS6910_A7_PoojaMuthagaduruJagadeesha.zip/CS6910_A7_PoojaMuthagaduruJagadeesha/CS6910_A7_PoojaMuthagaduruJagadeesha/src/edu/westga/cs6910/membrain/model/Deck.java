package edu.westga.cs6910.membrain.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import edu.westga.cs6910.membrain.resources.ExceptionMessages;

/**
 * The Class DeckOfCards.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 06/14/2024
 */
public class Deck implements Serializable {
	private static final long serialVersionUID = 1L;
	private ArrayList<Card> deckOfCards;
	
	/**
	 * Instantiates a new deck of cards.
	 */
	public Deck() {
		this.deckOfCards = new ArrayList<Card>();
		
		Suit[] suits = Suit.values();
		Rank[] ranks = Rank.values();
		
		for (Suit suit : suits) {
            for (Rank rank : ranks) {
            	this.deckOfCards.add(new Card(rank, suit));
            }
        }
		this.shuffle();
	}

	/**
	 * Gets the card deck.
	 *
	 * @return the card deck
	 */
	public ArrayList<Card> getCardDeck() {
		return this.deckOfCards;
	}
	
	/**
	 * Shuffles the deck of cards.
	 */
	public void shuffle() {
        Collections.shuffle(this.deckOfCards);
    }
	
	/**
	 * Deal card from the deck which removes the card dealt.
	 *
	 * @return the card
	 */
	public Card dealCard() {
        if (this.deckOfCards.isEmpty()) {
            return null;
        }
        return this.deckOfCards.remove(this.deckOfCards.size() - 1);
    }
	
	/**
	 * Adds the card to the deck if the card is not present.
	 *
	 * @param cardToAdd the card to add
	 */
	public void addCard(Card cardToAdd) {
		if (cardToAdd == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_CARD);
		}
		if (this.deckOfCards.contains(cardToAdd)) {
			throw new IllegalArgumentException(ExceptionMessages.CARD_EXIST);
		}
		this.deckOfCards.add(cardToAdd);
	}
}
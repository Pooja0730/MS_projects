package edu.westga.cs6910.membrain.test.computer_player;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs6910.membrain.model.ComputerPlayer;

public class TestComputerPlayer {

	private ComputerPlayer computerPlayer;

    @BeforeEach
    void setUp() {
        computerPlayer = new ComputerPlayer("Bot");
    }

    @Test
    void testSelectCard() {
        computerPlayer.selectCard(1);
    }

    @Test
    void testFlipCard() {
        computerPlayer.flipCard(1);
    }

    @Test
    void testHasMatchedCards() {
        assertFalse(computerPlayer.hasMatchedCards(), "Initial state should not have matched cards.");
    }

    @Test
    void testGetName() {
        assertEquals("Bot", computerPlayer.getName());
    }

    @Test
    void testScore() {
        assertEquals(0, computerPlayer.getScore());
        computerPlayer.incrementScore();
        assertEquals(1, computerPlayer.getScore());
    }

    @Test
    void testTurn() {
        assertFalse(computerPlayer.hasTurn());
        computerPlayer.setTurn(true);
        assertTrue(computerPlayer.hasTurn());
        computerPlayer.resetTurn();
        assertFalse(computerPlayer.hasTurn());
    }

    @Test
    void testMakeMove() {
        Set<Integer> moves = new HashSet<>();
        for (int i = 0; i < 100; i++) {
            int move = computerPlayer.makeMove(10);
            assertTrue(move >= 0 && move < 10, "Move should be within the range of 0 to 9.");
            moves.add(move);
        }
        assertTrue(moves.size() > 1, "Computer should make varied moves over multiple attempts.");
    }
}

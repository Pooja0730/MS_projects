package edu.westga.cs6910.membrain.model;

/**
 * The enum Suit.
 * 
 * @author CS6910
 * @version Summer 2024
 */
public enum Suit {

	SPADES,
	HEARTS,
	CLUBS,
	DIAMONDS;
}
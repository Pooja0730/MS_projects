package edu.westga.cs6910.membrain.test.deck;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.model.Deck;
import edu.westga.cs6910.membrain.model.Suit;


/**
 * Tests the Deck class Contructor
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 06/14/2024
 */
public class TestConstructor {

	@Test
	public void testDeckOfCardHas52Cards() {
		Deck testDeck = new Deck();
		int expectedSize = testDeck.getCardDeck().size();
		
		assertTrue(expectedSize == 52);
	}
	
	@Test
	public void testFirstCardOfTheDeckIsOfSpadesSuit() {
		Deck testDeck = new Deck();
		Card firstCard = testDeck.getCardDeck().get(0);
		
		assertEquals(Suit.CLUBS.name(), firstCard.getSuit());
	}
	
	@Test
	public void testLastCardOfTheDeckIsOfDiamondsSuit() {
		Deck testDeck = new Deck();
		Card lastCard = testDeck.getCardDeck().get(testDeck.getCardDeck().size() - 1);
		
		assertEquals(Suit.DIAMONDS.name(), lastCard.getSuit());
	}
}
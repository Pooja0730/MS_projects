package edu.westga.cs6910.membrain.game;

import java.io.Serializable;
import java.util.List;

import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.viewmodel.ViewCard;

/**
 * The Class SaveData.
 * 
 * @author CS6910
 * @version Summer 2024
 */
public class SaveData implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private List<Card> cardList;
	private Card firstCard;
	private Card secondCard;
	private int numberOfGuesses;
	private int score;
	private ViewCard cardView;
	
	/**
	 * Gets the card list.
	 *
	 * @return the card list
	 */
	public List<Card> getCardList() {
		return this.cardList;
	}
	
	/**
	 * Sets the card list.
	 *
	 * @param cardList the new card list
	 */
	public void setCardList(List<Card> cardList) {
		this.cardList = cardList;
	}
	
	/**
	 * Gets the first card.
	 *
	 * @return the first card
	 */
	public Card getFirstCard() {
		return this.firstCard;
	}
	
	/**
	 * Sets the first card.
	 *
	 * @param firstCard the new first card
	 */
	public void setFirstCard(Card firstCard) {
		this.firstCard = firstCard;
	}
	
	/**
	 * Gets the second card.
	 *
	 * @return the second card
	 */
	public Card getSecondCard() {
		return this.secondCard;
	}
	
	/**
	 * Sets the second card.
	 *
	 * @param secondCard the new second card
	 */
	public void setSecondCard(Card secondCard) {
		this.secondCard = secondCard;
	}
	
	/**
	 * Gets the number of guesses.
	 *
	 * @return the number of guesses
	 */
	public int getNumberOfGuesses() {
		return this.numberOfGuesses;
	}
	
	/**
	 * Sets the number of guesses.
	 *
	 * @param numberOfGuesses the new number of guesses
	 */
	public void setNumberOfGuesses(int numberOfGuesses) {
		this.numberOfGuesses = numberOfGuesses;
	}
	
	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	public int getScore() {
		return this.score;
	}
	
	/**
	 * Sets the score.
	 *
	 * @param score the new score
	 */
	public void setScore(int score) {
		this.score = score;
	}
	
	/**
	 * Gets the card view.
	 *
	 * @return the card view
	 */
	public ViewCard getCardView() {
		return this.cardView;
	}
	
	/**
	 * Sets the card view.
	 *
	 * @param cardView the new card view
	 */
	public void setCardView(ViewCard cardView) {
		this.cardView = cardView;
	}
}

package edu.westga.cs6910.membrain.test.human_player;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs6910.membrain.model.HumanPlayer;

import org.junit.jupiter.api.BeforeEach;

public class TestHumanPlayer {

	private HumanPlayer humanPlayer;

	@BeforeEach
	void setUp() {
		humanPlayer = new HumanPlayer("Pooja");
	}

	@Test
	void testSelectCard() {
		humanPlayer.selectCard(1);
	}

	@Test
	void testFlipCard() {
		humanPlayer.flipCard(1);
	}

	@Test
	void testHasMatchedCards() {
		assertFalse(humanPlayer.hasMatchedCards(), "Initial state should not have matched cards.");
	}

	@Test
	void testGetName() {
		assertEquals("Pooja", humanPlayer.getName());
	}

	@Test
	void testScore() {
		assertEquals(0, humanPlayer.getScore());
		humanPlayer.incrementScore();
		assertEquals(1, humanPlayer.getScore());
	}

	@Test
	void testTurn() {
		assertFalse(humanPlayer.hasTurn());
		humanPlayer.setTurn(true);
		assertTrue(humanPlayer.hasTurn());
		humanPlayer.resetTurn();
		assertFalse(humanPlayer.hasTurn());
	}
}
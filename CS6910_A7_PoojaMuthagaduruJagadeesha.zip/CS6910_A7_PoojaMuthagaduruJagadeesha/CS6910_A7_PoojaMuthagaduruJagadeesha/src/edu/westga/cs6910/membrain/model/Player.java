package edu.westga.cs6910.membrain.model;

import java.io.Serializable;

import edu.westga.cs6910.membrain.resources.ExceptionMessages;

// TODO: Auto-generated Javadoc
/**
 * The Class Player.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024 06/23/2024
 */
public abstract class Player implements Play, Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private int score;
	private boolean hasTurn;
	private int lastSelectedCard;
	private int lastFlippedCard;

	/**
	 * Instantiates a new player.
	 *
	 * @param name the name
	 */
	public Player(String name) {
		if (name == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_PLAYERNAME);
		}
		if (name.isBlank()) {
			throw new IllegalArgumentException(ExceptionMessages.EMPTY_PLAYERNAME);
		}

		this.name = name;
		this.score = 0;
		this.hasTurn = false;
		this.lastSelectedCard = -1;
		this.lastFlippedCard = -1;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	public int getScore() {
		return this.score;
	}

	/**
	 * Increment score.
	 */
	public void incrementScore() {
		this.score++;
	}

	/**
	 * Checks for turn.
	 *
	 * @return true, if successful
	 */
	public boolean hasTurn() {
		return this.hasTurn;
	}

	/**
	 * Sets the turn.
	 *
	 * @param hasTurn the new turn
	 */
	public void setTurn(boolean hasTurn) {
		this.hasTurn = hasTurn;
	}

	/**
	 * Reset turn.
	 */
	@Override
	public void resetTurn() {
		this.hasTurn = false;
	}

	/**
	 * Gets the last selected card.
	 *
	 * @return the last selected card
	 */
	public int getLastSelectedCard() {
		return this.lastSelectedCard;
	}

	/**
	 * Gets the last flipped card.
	 *
	 * @return the last flipped card
	 */
	public int getLastFlippedCard() {
		return this.lastFlippedCard;
	}

	/**
	 * Sets the last selected card.
	 *
	 * @param lastSelectedCard the new last selected card
	 */
	public void setLastSelectedCard(int lastSelectedCard) {
		this.lastSelectedCard = lastSelectedCard;
	}

	/**
	 * Sets the last flipped card.
	 *
	 * @param lastFlippedCard the new last flipped card
	 */
	public void setLastFlippedCard(int lastFlippedCard) {
		this.lastFlippedCard = lastFlippedCard;
	}
}

package edu.westga.cs6910.membrain.model;

import java.io.Serializable;
import java.util.Objects;

import edu.westga.cs6910.membrain.resources.ExceptionMessages;

/**
 * The Card class.
 * 
 * @author CS6910
 * @version Summer 2024
 */
public class Card implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	private Rank rank;
	private Suit suit;
	private boolean isMatched;

	/**
	 * Creates a playing card with the specified rank and suit.
	 * 
	 * @precondition valid rank and suit
	 * @postcondition getValue() == value && getSuit() == suit
	 * @param rank the rank of this card
	 * @param suit the suit of this card
	 */
	public Card(Rank rank, Suit suit) {
		if (rank == null) {
			throw new IllegalArgumentException(ExceptionMessages.INVALID_RANK);
		}
		if (suit == null) {
			throw new IllegalArgumentException(ExceptionMessages.INVALID_SUIT);
		}
		this.rank = rank;
		this.suit = suit;
		this.isMatched = false;
	}

	/**
	 * Returns the rank of this card.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the rank
	 */
	public int getRank() {
		return this.rank.getValue();
	}

	/**
	 * Returns the suit of this card.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the suit
	 */
	public String getSuit() {
		return this.suit.toString();
	}
	
	/**
	 * Checks if is matched.
	 *
	 * @return true, if is matched
	 */
	public boolean isMatched() {
        return this.isMatched;
    }

    /**
     * Sets the matched.
     *
     * @param matched the new matched
     */
    public void setMatched(boolean matched) {
        this.isMatched = matched;
    }
    
    /**
     * Gets the face.
     *
     * @return the face
     */
    public String getFace() {
        return this.getRank() + this.getSuit();
    }
    
    /**
     * Gets the color.
     *
     * @return the color
     */
    public String getColor() {
    	if (this.getSuit().equals("HEARTS") || this.getSuit().equals("DIAMONDS")) {
    		return "red";
    	} else {
    		return "black";
    	}
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
        	return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
        	return false;
        }
        Card card = (Card) obj;
        return this.suit.equals(card.suit) && this.rank.equals(card.rank);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.suit, this.rank);
    }

    @Override
    public String toString() {
        return this.rank + " of " + this.suit;
    }
    
    /**
     * Clone.
     *
     * @return the object
     * @throws CloneNotSupportedException the clone not supported exception
     */
    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}

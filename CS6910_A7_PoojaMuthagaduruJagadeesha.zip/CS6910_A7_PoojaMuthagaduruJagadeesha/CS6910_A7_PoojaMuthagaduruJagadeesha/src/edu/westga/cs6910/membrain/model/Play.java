package edu.westga.cs6910.membrain.model;

// TODO: Auto-generated Javadoc
/**
 * The Interface Play.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024 06/23/2024
 */
public interface Play {

	/**
	 * Select card.
	 *
	 * @param cardIndex the card index
	 */
	void selectCard(int cardIndex);
	
	/**
	 * Flip card.
	 *
	 * @param cardIndex the card index
	 */
	void flipCard(int cardIndex);
	
	/**
	 * Checks for matched cards.
	 *
	 * @return true, if successful
	 */
	boolean hasMatchedCards();
	
	/**
	 * Reset turn.
	 */
	void resetTurn();
}

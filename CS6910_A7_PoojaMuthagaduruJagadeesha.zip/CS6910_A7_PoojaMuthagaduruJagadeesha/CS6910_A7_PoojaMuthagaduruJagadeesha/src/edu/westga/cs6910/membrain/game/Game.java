package edu.westga.cs6910.membrain.game;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import edu.westga.cs6910.membrain.model.Card;
import edu.westga.cs6910.membrain.model.ComputerPlayer;
import edu.westga.cs6910.membrain.model.Deck;
import edu.westga.cs6910.membrain.model.HumanPlayer;
import edu.westga.cs6910.membrain.model.Player;
//import edu.westga.cs6910.membrain.viewmodel.ViewModel;

// TODO: Auto-generated Javadoc
/**
 * The Class Game.
 * 
 * @author Pooja Muthagaduru Jagadeesha
 * @version Summer 2024 06/23/2024
 */
public class Game implements Serializable {

	private static final long serialVersionUID = 1L;
	private Deck deck;
	private Player humanPlayer;
	private Player computerPlayer;
	private List<Card> selectedCards;

	/**
	 * Instantiates a new game.
	 *
	 * @param humanPlayerName the human player name
	 */
	public Game(String humanPlayerName) {
		this.deck = new Deck();
		this.humanPlayer = new HumanPlayer(humanPlayerName);
		this.computerPlayer = new ComputerPlayer("Computer");
		this.selectedCards = new ArrayList<Card>();
		this.initializeGame();
	}

	/**
	 * Gets the deck.
	 *
	 * @return the deck
	 */
	public Deck getDeck() {
		return this.deck;
	}

	/**
	 * Gets the human player.
	 *
	 * @return the human player
	 */
	public Player getHumanPlayer() {
		return this.humanPlayer;
	}

	/**
	 * Gets the computer player.
	 *
	 * @return the computer player
	 */
	public Player getComputerPlayer() {
		return this.computerPlayer;
	}

	/**
	 * Gets the selected cards.
	 *
	 * @return the selected cards
	 */
	public List<Card> getSelectedCards() {
		return this.selectedCards;
	}

	/**
	 * Initialize game.
	 */
	private void initializeGame() {
		this.deck.shuffle();
	}

	/**
	 * Play turn.
	 *
	 * @param player the player
	 * @param cardIndex the card index
	 */
	public void playTurn(Player player, int cardIndex) {
		Card selectedCard = this.deck.getCardDeck().get(cardIndex);
		player.selectCard(cardIndex);
		player.flipCard(cardIndex);
		this.selectedCards.add(selectedCard);
		if (this.selectedCards.size() == 2) {
			if (this.checkForMatch()) {
				player.incrementScore();
				this.selectedCards.forEach(card -> card.setMatched(true));
			}
			this.selectedCards.clear();
		}
		player.resetTurn();
	}

	/**
	 * Check for match.
	 *
	 * @return true, if successful
	 */
	public boolean checkForMatch() {
		return this.selectedCards.get(0).getFace().equals(this.selectedCards.get(1).getFace());
	}

	/**
	 * Play game.
	 */
	public void playGame() {
		this.humanPlayer.setTurn(true);
		this.playTurn(this.humanPlayer, 0);
		this.playTurn(this.humanPlayer, 1);
		this.computerPlayer.setTurn(true);
		this.playTurn(this.computerPlayer, 2);
		this.playTurn(this.computerPlayer, 3);

		System.out.println(this.humanPlayer.getName() + "'s score: " + this.humanPlayer.getScore());
		System.out.println(this.computerPlayer.getName() + "'s score: " + this.computerPlayer.getScore());
	}
	
	/**
	 * Save game state.
	 *
	 * @param fileName the file name
	 */
	public void saveGameState(String fileName) {
        try (FileOutputStream fileOut = new FileOutputStream(fileName);
             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
            out.writeObject(this);
            System.out.println("Game state saved to " + fileName);
        } catch (IOException ex) {
        	ex.printStackTrace();
        }        
    }
	
	/**
	 * Load game.
	 *
	 * @param fileName the file name
	 */
	public void loadGame(String fileName) {
        //ViewModel restoredViewModel = null;
        try (FileInputStream fileIn = new FileInputStream(fileName);
             ObjectInputStream in = new ObjectInputStream(fileIn)) {
            /*restoredViewModel = (ViewModel)*/ in.readObject();
            System.out.println("Game state restored from " + fileName);
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        //return restoredViewModel;
    }
}

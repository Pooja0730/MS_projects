package edu.westga.cs6311.books.controller;

import edu.westga.cs6311.books.view.BookView;

/**
 * This is a controller class which has the starting point for the Book application
 * @author Pooja Muthagaduru Jagadeesha
 * @version 09/20/2023
 */
public class Driver {
	
	/**
	 * Entry-point to the application
	 * @param args Not used
	 */
	public static void main(String[] args) {
		BookView viewObject = new BookView();
		viewObject.run();
	}

}

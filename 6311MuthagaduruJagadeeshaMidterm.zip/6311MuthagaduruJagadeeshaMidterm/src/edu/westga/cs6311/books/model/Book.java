package edu.westga.cs6311.books.model;

/**
 * This is a model class which describes the Book passed as an input
 * @author Pooja Muthagaduru Jagadeesha
 * @version 09/20/2023
 */
public class Book {
	private String title;
	private String author;
	private int numberOfStories;
	private Story firstStory;
	private Story secondStory;
	private Story thirdStory;
	
	/**
	 * 2-parameter constructor which is used to initialize the instance variables
	 * @param title This holds the book's title passed by the user
	 * @param author This holds the book's author name passed by the user
	 */
	public Book(String title, String author) {
		this.title = title;
		this.author = author;
		this.numberOfStories = 0;
		this.firstStory = null;
		this.secondStory = null;
		this.thirdStory = null;
	}
	
	/**
	 * This is a getter method for the book's title instance variable
	 * @return Returns the book's title
	 */
	public String getTitle() {
		return this.title;
	}
	
	/**
	 * This is a getter method for the book's author instance variable
	 * @return Returns the book's author
	 */
	public String getAuthor() {
		return this.author;
	}
	
	/**
	 * This is a getter method for book's number of stories instance variable
	 * @return Returns the book's number of stories value
	 */
	public int getNumberOfStories() {
		return this.numberOfStories;
	}
	
	/**
	 * This is a method to add a story into the book according to the story number
	 * @param story This holds the value of story object passed by the user
	 * @param storyNumber This holds the value of the story number which needs to be added
	 */
	public void addStory(Story story, int storyNumber) {
		if (storyNumber == 1) {
			this.firstStory = story;
			this.numberOfStories++;
		} else if (storyNumber == 2) {
			this.secondStory = story;
			this.numberOfStories++;
		} else if (storyNumber == 3) {
			this.thirdStory = story;
			this.numberOfStories++;
		}
	}
	
	/**
	 * This method calculates the average rating of all the stories of the book
	 * @return Returns the calculated average of ratings
	 */
	public double getAverageRating() {
		if (this.firstStory != null && this.secondStory != null && this.thirdStory != null) {
			return (this.firstStory.getRating() + this.secondStory.getRating() + this.thirdStory.getRating()) / 3;
		} else if (this.firstStory != null && this.secondStory != null) {
			return (this.firstStory.getRating() + this.secondStory.getRating()) / 2;
		} else if (this.firstStory != null) {
			return this.firstStory.getRating();
		} else {
			return 0.0;
		}
	}
	
	/**
	 * This method gets the total number of times the stories are read of the book
	 * @return Returns the total number of times the stories read
	 */
	public int getTotalStoriesRead() {
		if (this.firstStory != null && this.secondStory != null && this.thirdStory != null) {
			return this.firstStory.getTimesRead() + this.secondStory.getTimesRead() + this.thirdStory.getTimesRead();
		} else if (this.firstStory != null && this.secondStory != null) {
			return this.firstStory.getTimesRead() + this.secondStory.getTimesRead();
		} else if (this.firstStory != null) {
			return this.firstStory.getTimesRead();
		} else {
			return 0;
		}
	}
	
	/**
	 * This method reads all the stories of the book
	 */
	public void readAllStories() {
			this.firstStory.read();
			this.secondStory.read();
			this.thirdStory.read();
	}
	
	/**
	 * This method reads the story according to the story number
	 * @param storyNumber This holds the story number which is asked to be read
	 */
	public void readStory(int storyNumber) {
		if (storyNumber == 1) {
			this.firstStory.read();
		} else if (storyNumber == 2) {
			this.secondStory.read();
		} else if (storyNumber == 3) {
			this.thirdStory.read();
		}
	}
	
	/**
	 * This method gathers all the information about the book as a string
	 * @return Returns the gathers information of the book
	 */
	public String toString() {
		return "Book [Title=" + this.title 
				+ ", Author=" + this.author 
				+ ", Number of stories=" + this.numberOfStories 
				+ ", \n\tFirst story=" + this.firstStory.toString()
				+ ", \n\tSecond story=" + this.secondStory.toString()
				+ ", \n\tThird story=" + this.thirdStory.toString() + "]";
	}
}

package edu.westga.cs6311.books.model;

/**
 * This is a model class which describes the Story of the book passed as an input
 * @author Pooja Muthagaduru Jagadeesha
 * @version 09/20/2023
 */
public class Story {
	private String title;
	private int rating;
	private int numberOfPages;
	private int timesRead;
	
	/**
	 * 3-parameter constructor which is used to initialize the instance variables
	 * @param title This holds the story title passed by the user
	 * @param rating This holds the story rating passed by the user
	 * @param numberOfPages This holds the number of pages of the story passed by the user
	 */
	public Story(String title, int rating, int numberOfPages) {
		this.title = title;
		this.rating = rating;
		this.numberOfPages = numberOfPages;
		this.timesRead = 0;
	}
	
	/**
	 * This is a getter method for story's title instance variable
	 * @return Returns the story's title
	 */
	public String getTitle() {
		return this.title;
	}
	
	/**
	 * This is a getter method for story's rating instance variable
	 * @return Returns the story's rating
	 */
	public int getRating() {
		return this.rating;
	}
	
	/**
	 * This is a getter method for number of pages instance variable
	 * @return Returns the number of pages of the story
	 */
	public int getNumberOfPages() {
		return this.numberOfPages;
	}
	
	/**
	 * This is a getter method for instance variable which holds number of times the story is read
	 * @return Returns the value of number of times the story is read
	 */
	public int getTimesRead() {
		return this.timesRead;
	}
	
	/**
	 * This method increments the value of number of times the story is read when the story is read
	 */
	public void read() {
		this.timesRead += 1;
	}
	
	/**
	 * This method gathers all the information about the story as a string
	 * @return Returns the gathers information of the story
	 */
	public String toString() {
		return "Story [Title=" + this.title 
					+ ", Rating=" + this.rating 
					+ ", Number of pages=" + this.numberOfPages 
					+ ", Number of times read=" + this.timesRead + "]";
	}
}
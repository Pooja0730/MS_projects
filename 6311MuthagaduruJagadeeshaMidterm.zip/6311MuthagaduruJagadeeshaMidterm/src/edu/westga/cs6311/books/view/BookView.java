package edu.westga.cs6311.books.view;

import java.util.Scanner;

import edu.westga.cs6311.books.model.Book;
import edu.westga.cs6311.books.model.Story;

/**
 * This is a view class for the Book application which interacts with the user to get the information to be added to create a book
 * @author Pooja Muthagaduru Jagadeesha
 * @version 09/20/2023
 */
public class BookView {
	private Scanner keyboard;
	private Book firstBook;
	private Book secondBook;
	
	/**
	 * 0-parameter constructor to initialize the instance variable
	 */
	public BookView() {
		this.keyboard = new Scanner(System.in);
		this.firstBook = null;
		this.secondBook = null;
	}
	
	/**
	 * This method helps to kick start the application by getting the input from the user and to interact with the model class of 
	 * the Book application
	 */
	public void run() {
		this.firstBook = this.buildBook();
		this.secondBook = this.buildBook();
		
		this.readBook(this.secondBook);
		System.out.println("The details of second book is: \n" + this.secondBook.toString());
		
		this.readBook(this.firstBook);
		this.readBook(this.firstBook);
		System.out.println("\nThe details of second book is: \n" + this.secondBook.toString());
		
		this.readStory(this.firstBook, 1);
		this.readStory(this.firstBook, 1);
		this.readStory(this.firstBook, 2);
		this.readStory(this.firstBook, 3);
		this.readStory(this.firstBook, 3);
		System.out.println("\nThe details of first book is: \n" + this.firstBook.toString());
		System.out.println("\nThe details of second book is: \n" + this.secondBook.toString());
	}
	
	private Book getBookInformation() {
		System.out.print("Enter the title of the book: ");
		String inputTitle = this.keyboard.nextLine();
		
		System.out.print("Enter the author of the book: ");
		String inputAuthor = this.keyboard.nextLine();
		
		Book bookObject = new Book(inputTitle, inputAuthor);
		return bookObject;
	}
	
	private Story getStoryInformation() {
		System.out.print("\nEnter the title of the story: ");
		String inputStoryTitle = this.keyboard.nextLine();
		
		System.out.print("Enter the rating(1 to 3) of this story: ");
		String inputRating = this.keyboard.nextLine();
		int rating = Integer.parseInt(inputRating);
		
		System.out.print("Enter the number of pages in this story: ");
		String inputNumberOfPages = this.keyboard.nextLine();
		int numberOfPages = Integer.parseInt(inputNumberOfPages);
		
		Story storyObject = new Story(inputStoryTitle, rating, numberOfPages);
		return storyObject;
	}
	
	private void addStoryToBook(Book book, Story story, int storyPosition) {
		book.addStory(story, storyPosition);
	}
	
	private void readStory(Book book, int storyNumber) {
		book.readStory(storyNumber);
	}
	
	private void readBook(Book book) {
		book.readAllStories();
	}
	
	private Book buildBook() {
		Book book = this.getBookInformation();
		Story story1 = this.getStoryInformation();
		this.addStoryToBook(book, story1, 1);
		
		Story story2 = this.getStoryInformation();
		this.addStoryToBook(book, story2, 2);
		
		Story story3 = this.getStoryInformation();
		this.addStoryToBook(book, story3, 3);
		System.out.println("\n");
		return book;
	}
}

package edu.westga.cs6311.project02.controller;

import edu.westga.cs6311.project02.view.TruckSalesView;

/**
 * This is a controller class which has the starting point for the Truck application
 * @author Pooja Muthagaduru Jagadeesha
 * @version 12/06/2023
 */
public class Driver {

	/**
	 * Entry-point to the application
	 * @param args Not used
	 */
	public static void main(String[] args) {
		TruckSalesView theView = new TruckSalesView();
		theView.run();

	}

}

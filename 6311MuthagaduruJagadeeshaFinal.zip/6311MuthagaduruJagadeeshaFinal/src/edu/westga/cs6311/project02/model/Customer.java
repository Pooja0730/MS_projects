package edu.westga.cs6311.project02.model;

/**
 * This is a model class for the Customer System
 * @author Pooja Muthagaduru Jagadeesha
 * @version 12/06/2023
 */
public class Customer {
	private String name;
	private double moneyAvailable;
	private Truck chosenTruck;
	
	/**
	 * A 2-parameter constructor that accepts values for the customer's name and money available. 
	 * This should set the chosen truck to null.
	 * @param name This holds the value of the customer's name
	 * @param moneyAvailable This holds the value of the money available with the customers
	 */
	public Customer(String name, double moneyAvailable) {
		if (name == null) {
			new IllegalArgumentException("Customer name cannot be null");
		}
		if (moneyAvailable <= 0) {
			new IllegalArgumentException("Money availability cannot be less than or equal to 0");
		}
		this.name = name;
		this.moneyAvailable = moneyAvailable;
		this.chosenTruck = null;
	}

	/**
	 * Getter method for the customer name
	 * @return Returns the value of the customer name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Getter method for the customer money availability
	 * @return Returns the value of the customer money availability
	 */
	public double getMoneyAvailable() {
		return this.moneyAvailable;
	}

	/**
	 * Getter method for the customer's chosen truck
	 * @return Returns the value of the customer's chosen truck
	 */
	public Truck getChosenTruck() {
		return this.chosenTruck;
	}
	
	/**
	 * This method validates whether the customer can purchase the truck or not.
	 * @param truck This holds the truck which can be purchased
	 * @return Returns true if the customer can purchase the truck else false
	 */
	public boolean canPurchase(Truck truck) {
		 TruckInventory inventoryObject = new TruckInventory();
		 if (inventoryObject.getFinalTruckPrice(truck) <= this.getMoneyAvailable()) {
			 return true;
		 }
		 return false;
	 }
	 
	/**
	 * This method calculates and sets the amount of money the customer has left after purchasing the truck.
	 * @param truck This holds the truck which is purchased
	 */
	public void purchase(Truck truck) {
		 this.chosenTruck = truck;
		 TruckInventory inventoryObject = new TruckInventory();
		 this.moneyAvailable = this.moneyAvailable - inventoryObject.getFinalTruckPrice(this.chosenTruck);
	 }
}

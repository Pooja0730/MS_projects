package edu.westga.cs6311.project02.model;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * This is a model class for the Truck System
 * @author Pooja Muthagaduru Jagadeesha
 * @version 12/06/2023
 */
public class Truck {
	private String manufacturer;
	private int torque;
	private double price;
	private int satisfaction;
	 
	/**
	 * A 4-parameter constructor that accepts values for the truck's instance variables.
	 * @param manufacturer This holds the name of the manufacturer
	 * @param torque This holds the torque of the truck
	 * @param price This holds the price of the truck
	 * @param satisfaction This holds the customer satisfaction rate
	 */
	public Truck(String manufacturer, int torque, double price, int satisfaction) {
		if (manufacturer == null || manufacturer.equals("null") || manufacturer.trim().equals("")) {
			new IllegalArgumentException("Manufacturer cannot be null or blank");
		}
		if (torque <= 0) {
			new IllegalArgumentException("Torque cannot be less than or equal to 0");
		}
		if (price <= 0.0) {
			new IllegalArgumentException("Price cannot be less than or equal to 0");
		}
		if (satisfaction < 0 || satisfaction > 9) {
			new IllegalArgumentException("Customer satisfaction cannot be less than 0 or greater than 9");
		}
		this.manufacturer = manufacturer;
		this.torque = torque;
		this.price = price;
		this.satisfaction = satisfaction;
	}
	
	/**
	 * A 4-parameter constructor that accepts values for the truck's instance variables. This constructor will set the customer satisfaction to 0 (zero).
	 * @param manufacturer This holds the name of the manufacturer
	 * @param torque This holds the torque of the truck
	 * @param price This holds the price of the truck
	 */
	public Truck(String manufacturer, int torque, double price) {
		if (manufacturer == null || manufacturer.equals("null") || manufacturer.trim().equals("")) {
			new IllegalArgumentException("Manufacturer cannot be null or blank");
		}
		if (torque <= 0) {
			new IllegalArgumentException("Torque cannot be less than or equal to 0");
		}
		if (price <= 0.0) {
			new IllegalArgumentException("Price cannot be less than or equal to 0");
		}
		this.manufacturer = manufacturer;
		this.torque = torque;
		this.price = price;
		this.satisfaction = 0;
	}
	
	/**
	 * Getter method for the manufacturer instance variable
	 * @return Returns the value of the manufacturer
	 */
	public String getManufacturer() {
		return this.manufacturer;
	}

	/**
	 * Getter method for the torque instance variable
	 * @return Returns the value of the torque
	 */
	public int getTorque() {
		return this.torque;
	}

	/**
	 * Getter method for the price instance variable
	 * @return Returns the value of the price
	 */
	public double getPrice() {
		return this.price;
	}

	/**
	 * Getter method for the customer satisfaction instance variable
	 * @return Returns the value of the customer satisfaction
	 */
	public int getSatisfaction() {
		return this.satisfaction;
	}
	
	/**
	 * Setter method for the price instance variable
	 * @param price The price of the truck
	 */
	public void setPrice(double price) {
		if (price <= 0.0) {
			new IllegalArgumentException("Price cannot be less than or equal to 0");
		}
		this.price = price;
	}

	/**
	 * Setter method for the customer satisfaction instance variable
	 * @param satisfaction The customer satisfaction rate of the truck
	 */
	public void setSatisfaction(int satisfaction) {
		if (satisfaction < 0 || satisfaction > 9) {
			new IllegalArgumentException("Customer satisfaction cannot be less than 0 or greater than 9");
		}
		this.satisfaction = satisfaction;
	}
	
	/**
	 * This method formats the description of the truck like it's price to US dollars according to the customer satisfaction value
	 */
	public void getFormattedDescription() {
		Locale usa = new Locale("en", "US");
		NumberFormat dollarFormat = NumberFormat.getCurrencyInstance(usa);
		
		if (this.getSatisfaction() != 0) {
			System.out.printf("%-15s %-10s %-15s %-1s\n", this.getManufacturer(), this.getTorque(), dollarFormat.format(this.getPrice()), this.getSatisfaction());
		} else {
			System.out.printf("%-15s %-10s %-15s %-1s\n", this.getManufacturer(), this.getTorque(), dollarFormat.format(this.getPrice()), "?");
		}
	}
}

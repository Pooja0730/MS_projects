package edu.westga.cs6311.project02.model;

import java.util.ArrayList;

/**
 * This is a model class for the Truck Inventory System
 * @author Pooja Muthagaduru Jagadeesha
 * @version 12/06/2023
 */
public class TruckInventory {
	public static final double TAX_RATE = 9.5;
	private ArrayList<Truck> inventory;

	/**
	 *  A 0-parameter constructor that instantiates the inventory data member
	 */
	public TruckInventory() {
		this.inventory = new ArrayList<Truck>();
		this.addInventory();
	}

	/**
	 * A private method which adds four new Truck objects to the inventory
	 */
	private void addInventory() {
		Truck firstTruck = new Truck("Kenworth", 1550, 176000);
		Truck secondTruck = new Truck("Freightliner", 2115, 160000, 7);
		Truck thirdTruck = new Truck("Peterbilt", 1550, 165000, 6);
		Truck forthTruck = new Truck("Mack", 1260, 125000);

		this.inventory.add(firstTruck);
		this.inventory.add(secondTruck);
		this.inventory.add(thirdTruck);
		this.inventory.add(forthTruck);
	}

	/**
	 * This method that accepts a price and returns an ArrayList
	 * holding all of the Truck objects below that price.
	 */
	/**
	 * This method accepts a price and returns a list of trucks which are under the mentioned price
	 * @param price This holds the value of price
	 * @return Returns a list of trucks which are under the price
	 */
	public ArrayList<Truck> findTrucksUnder(double price) {
		ArrayList<Truck> trucksUnderPrice = new ArrayList<Truck>();
		for (Truck truck : this.inventory) {
			if (truck.getPrice() < price) {
				trucksUnderPrice.add(truck);
			}
		}
		return trucksUnderPrice;
	}

	/**
	 * This method is used to search for the truck from the inventory to buy it and to remove it from the inventory
	 * @param manufacturer This holds the value of the manufacturer
	 * @return Returns a Truck which has been bought or null if truck is not found in the inventory
	 */
	public Truck buyTruck(String manufacturer) {
		Truck truckBought = null;
		String uppercaseTruck = "";
		ArrayList<Truck> newInventory = new ArrayList<Truck>(this.inventory);
		for (Truck truck : this.inventory) {
			uppercaseTruck = truck.getManufacturer().toUpperCase();
			if (uppercaseTruck.equals(manufacturer.toUpperCase())) {
				truckBought = truck;
				newInventory.remove(truck);
			}
		}
		this.inventory = newInventory;
		return truckBought;
	}

	/**
	 * This method adds a new truck to the inventory along with the customer satisfaction rating
	 * @param manufacturer This holds the value of the manufacturer
	 * @param torque This holds the value of the torque
	 * @param price This holds the value of the price
	 * @param satisfaction This holds the value of the customer satisfaction rating
	 */
	public void addTruck(String manufacturer, int torque, double price, int satisfaction) {
		Truck newTruck = new Truck(manufacturer, torque, price, satisfaction);
		this.inventory.add(newTruck);
	}

	/**
	 * An addTruck method that does the following: o Has the following parameters:
	 * manufacturer, torque and price o Creates a new Truck object based on the
	 * parameter values and adds the Truck object to the inventory.
	 */

	/**
	 * This method adds a new truck to the inventory without the customer satisfaction rating
	 * @param manufacturer This holds the value of the manufacturer
	 * @param torque This holds the value of the torque
	 * @param price This holds the value of the price
	 */
	public void addTruck(String manufacturer, int torque, double price) {
		Truck newTruck = new Truck(manufacturer, torque, price);
		this.inventory.add(newTruck);
	}

	/**
	 * A getFinalTruckPrice method that does the following: o Accepts a Truck object
	 * and then returns the total cost of the purchase based on the price of the
	 * truck and the tax rate.
	 * 
	 */
	/**
	 * This method calculates the total cost of the purchase based on the price of the
	 * truck and the tax rate.
	 * @param truck This holds the truck of which the total cost needs to be calculated
	 * @return Returns the calculated total cost of the truck
	 */
	public double getFinalTruckPrice(Truck truck) {
		double finalTruckPrice = truck.getPrice() + ((TAX_RATE / 100) * truck.getPrice());
		return finalTruckPrice;
	}

	/**
	 * This method searches the inventory of trucks to return the truck which has the highest torque.
	 * @return Returns the truck with highest torque or null if no trucks are present in the inventory
	 */
	public Truck getMostPowerfulTruck() {
		Truck mostPowerfulTruck = null;
		int highestTorque = Integer.MIN_VALUE;
		for (Truck truck : this.inventory) {
			if (truck.getTorque() > highestTorque) {
				highestTorque = truck.getTorque();
				mostPowerfulTruck = truck;
			}
		}
		return mostPowerfulTruck;
	}

	/**
	 * A getLeastExpensiveTruck that returns a Truck object and does the following:
	 * o Iterates through the inventory and finds the least expensive truck and
	 * returns that Truck object. o If there are not any trucks in the inventory,
	 * this method should return null.
	 */
	/**
	 * This method searches the inventory of trucks to return the truck which has the lowest price.
	 * @return Returns the truck with lowest price or null if no trucks are present in the inventory
	 */
	public Truck getLeastExpensiveTruck() {
		Truck leastExpensiveTruck = null;
		double leastPrice = Double.MAX_VALUE;
		for (Truck truck : this.inventory) {
			if (truck.getPrice() < leastPrice) {
				leastPrice = truck.getPrice();
				leastExpensiveTruck = truck;
			}
		}
		return leastExpensiveTruck;
	}

	/**
	 * This method that returns the number of trucks in the inventory.
	 * @return Returns the number of trucks present in the inventory
	 */
	public int size() {
		return this.inventory.size();
	}

	/**
	 * This method searches the inventory if a manufacturer is present in the truck inventory
	 * @param manufacturer This holds the value of the manufacturer
	 * @return Returns true if the truck inventory has the manufacturer or returns false if it doesn't
	 */
	public boolean contains(String manufacturer) {
		String uppercaseTruck = "";
		for (Truck truck : this.inventory) {
			uppercaseTruck = truck.getManufacturer().toUpperCase();
			if (uppercaseTruck.equals(manufacturer.toUpperCase())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * This method the store's inventory
	 * @return Returns a list of trucks in the inventory
	 */
	public ArrayList<Truck> getInventory() {
		return this.inventory;
	}
}

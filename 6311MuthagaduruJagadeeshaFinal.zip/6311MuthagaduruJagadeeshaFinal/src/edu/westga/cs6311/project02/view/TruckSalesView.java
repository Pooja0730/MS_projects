package edu.westga.cs6311.project02.view;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

import edu.westga.cs6311.project02.model.Customer;
import edu.westga.cs6311.project02.model.Truck;
import edu.westga.cs6311.project02.model.TruckInventory;

/**
 * This is a view class for the Truck purchase application which interacts with the user
 * @author Pooja Muthagaduru Jagadeesha
 * @version 12/06/2023
 */
public class TruckSalesView {
	private Scanner keyboard;
	
	/**
	 * 0-parameter constructor to initialize the instance variable
	 */
	public TruckSalesView() {
		this.keyboard = new Scanner(System.in);
	}
	
	/**
	 * This method helps to kick start the application by getting the input from the user and 
	 * to interact with the model classes of the truck purchase application
	 */
	public void run() {
		TruckInventory theInventory = new TruckInventory();
		Customer theCustomer = null;
		
		System.out.println("Welcome to the Truck Inventory! Here are some of the trucks present in the inventory: \n");
		System.out.printf("%-15s %-10s %-15s %-1s\n", "Manufacturer", "Torque", "Price", "Customer Satisfaction");
		for (Truck truck : theInventory.getInventory()) {
			truck.getFormattedDescription();
		}
		this.displayMainMenu(theInventory, theCustomer);
	}
	
	/**
	 * This method displays a main menu system which allows the user to serve a customer, add a new
	 * truck to the inventory, view the inventory or close the store.
	 * @param theInventory This holds the object reference of the truck inventory class
	 * @param theCustomer This holds the object reference of the customer class
	 */
	private void displayMainMenu(TruckInventory theInventory, Customer theCustomer) {
		System.out.println("\n1 - Serve Customer");
		System.out.println("2 - Add truck");
		System.out.println("3 - View inventory");
		System.out.println("4 - Close store");
		System.out.print("\nPlease enter the option number from the above displayed menu: ");
		String input = this.keyboard.nextLine();
		
		if (input.equals("1")) {
			this.serveCustomer(theInventory, theCustomer);
		} else if (input.equals("2")) {
			this.addTruck(theInventory);
		} else if (input.equals("3")) {
			this.viewInventory(theInventory);
		} else if (input.equals("4")) {
			this.closeStore();
		} else {
			System.out.print("Option Entered is not appropriate, please choose the option number from the displayed menu!");
			this.displayMainMenu(theInventory, theCustomer);
		}
	}
 
	/**
	 * This method is used to display a message to the customer and to exit the application
	 */
	private void closeStore() {
		System.out.println("The Store is closed! Thank you.");
	}

	/**
	 * This method is used to view the inventory in a particular format
	 * @param theInventory This holds the object reference of the truck inventory class
	 */
	private void viewInventory(TruckInventory theInventory) {
		double totalRate = 0;
		int count = 0;
		
		for (Truck truck : theInventory.getInventory()) {
			if (truck.getSatisfaction() != 0) {
				count++;
				totalRate += truck.getSatisfaction();
			}
		}
		double averageRate = totalRate / count;
		System.out.printf("\nInventory of " + theInventory.size() + " trucks with average rating of %.1f for rated trucks", averageRate);
		
		System.out.printf("\n%-15s %-10s %-15s %-1s\n", "Manufacturer", "Torque", "Price", "Customer Satisfaction");
		for (Truck truck : theInventory.getInventory()) {
			truck.getFormattedDescription();
		}
		
		Truck mostPowerfulTruck = theInventory.getMostPowerfulTruck();
		System.out.println("\nMost powerful truck: ");
		System.out.printf("\n%-15s %-10s %-15s %-1s\n", "Manufacturer", "Torque", "Price", "Customer Satisfaction");
		mostPowerfulTruck.getFormattedDescription();
		
		Truck leastExpensiveTruck = theInventory.getLeastExpensiveTruck();
		System.out.println("\nLeast Expensive truck: ");
		System.out.printf("\n%-15s %-10s %-15s %-1s\n", "Manufacturer", "Torque", "Price", "Customer Satisfaction");
		leastExpensiveTruck.getFormattedDescription();
	}

	/**
	 * This method is used to get the data to add the truck into the inventory and to 
	 * display the updated inventory
	 * @param theInventory This holds the object reference of the truck inventory class
	 */
	private void addTruck(TruckInventory theInventory) {
		int torque = 0;
		double price = 0;
		String input = "";
		System.out.println("Please enter the manufacturer: ");
		String manufacturer = this.keyboard.nextLine();
		
		do {
			System.out.println("Please enter the torque which should be greater than 0: ");
			input = this.keyboard.nextLine();
			torque = Integer.parseInt(input);
		} while (torque <= 0);
		
		do {
			System.out.print("Please enter the price which should be greater than 0: ");
			input = this.keyboard.nextLine();
			price = Double.parseDouble(input);
		} while (price <= 0.0);
		
		theInventory.addTruck(manufacturer, torque, price);
		System.out.println("The new inventory now consists of: ");
		for (Truck truck : theInventory.getInventory()) {
			truck.getFormattedDescription();
		}
	}

	/**
	 * This method is used to get the data of the customer and according to that serve the customer 
	 * as per their needs with the truck inventory
	 * @param theInventory This holds the object reference of the truck inventory class
	 * @param theCustomer This holds the object reference of the customer class
	 */
	private void serveCustomer(TruckInventory theInventory, Customer theCustomer) {
		System.out.print("\nPlease enter the name of the customer: ");
		String inputName = this.keyboard.nextLine();
		
		System.out.print("\nPlease enter the money available with this customer: ");
		String inputMoney = this.keyboard.nextLine();
		double moneyAvailable  = Double.parseDouble(inputMoney);
		
		theCustomer = new Customer(inputName, moneyAvailable);
		
		if (theInventory.findTrucksUnder(moneyAvailable).size() >= 1) {
			this.displayCustomerMenu(inputName, theInventory, theCustomer);
		} else {
			System.out.println("Insufficient availability of money! To purchase a truck you must have at least of $" + theInventory.getLeastExpensiveTruck().getPrice());
			this.displayMainMenu(theInventory, theCustomer);
		}
	}

	/**
	 * This method displays a customer menu system which allows the customer to view the inventory,
	 *  to check for the trucks under the price according to the customer, to purchase the truck or 
	 *  to leave the store.
	 * @param customerName This holds the value of the customer name
	 * @param theInventory This holds the object reference of the truck inventory class
	 * @param theCustomer This holds the object reference of the truck inventory class
	 */
	private void displayCustomerMenu(String customerName, TruckInventory theInventory, Customer theCustomer) {
		System.out.println("\n1 - View inventory");
		System.out.println("2 - View trucks under price");
		System.out.println("3 - Purchase truck");
		System.out.println("4 - Leave store");
		System.out.print(customerName + ", please enter your choice: ");
		String input = this.keyboard.nextLine();
		
		if (input.equals("1")) {
			this.viewInventory(theInventory);
		} else if (input.equals("2")) {
			this.viewTrucksUnderPrice(theInventory, theCustomer);
		} else if (input.equals("3")) {
			this.purchaseTruck(theInventory, theCustomer);
		} else if (input.equals("4")) {
			this.leaveStore(theInventory, theCustomer);
		} else {
			System.out.print("Option Entered is not appropriate, please choose the option number from the displayed customer menu!");
			this.displayCustomerMenu(customerName, theInventory, theCustomer);
		}
	}

	/**
	 * This method displays a message stating a thank you message.
	 * @param theInventory This holds the object reference of the truck inventory class
	 * @param theCustomer This holds the object reference of the customer class
	 */
	private void leaveStore(TruckInventory theInventory, Customer theCustomer) {
		System.out.println("Thank you! Visit us again.");
		System.out.println("The amount of money you have left is: " + theCustomer.getMoneyAvailable());
		this.displayMainMenu(theInventory, theCustomer);
	}

	/** 
	 * This method is used to get the data of the manufacturer from the customer in order 
	 * to purchase the truck if present in the inventory and to display an appropriate message
	 *  to the customer
	 * @param theInventory This holds the object reference of the truck inventory class
	 * @param theCustomer This holds the object reference of the customer class
	 */
	private void purchaseTruck(TruckInventory theInventory, Customer theCustomer) {
		System.out.println("Please enter the manufacturer of the truck to purchase: ");
		String inputManufacturer = this.keyboard.nextLine();
		String uppercaseTruck = "";
		
		for (Truck truck : theInventory.getInventory()) {
			uppercaseTruck = truck.getManufacturer().toUpperCase();
			if (uppercaseTruck.equals(inputManufacturer.toUpperCase())) {
				this.validateCanPurchase(theInventory, truck, inputManufacturer, theCustomer);
			}
		}
		System.out.println("The truck of the requested manufacturer is not present in the inventory");
		this.displayCustomerMenu(theCustomer.getName(), theInventory, theCustomer);
	}

	/**
	 * This method is used to validate whether the customer can purchase the truck or not
	 * @param theInventory This holds the object reference of the truck inventory class
	 * @param truck This holds the object reference of the truck object
	 * @param manufacturer This holds the value of the manufacturer which can be purchased by the customer
	 * @param theCustomer This holds the object reference of the customer class
	 */
	private void validateCanPurchase(TruckInventory theInventory, Truck truck, String manufacturer, Customer theCustomer) {
		if (theCustomer.canPurchase(truck)) {
			theCustomer.purchase(truck);
			theInventory.buyTruck(manufacturer);
			System.out.println("Thank you for purchasing the truck - " + truck.getManufacturer() 
			+ "\nwhich costs: " + theInventory.getFinalTruckPrice(truck) 
			+ "\nThe amount of money left is: " + theCustomer.getMoneyAvailable());
			this.displayMainMenu(theInventory, theCustomer);
		} else {
			System.out.println("Insufficient amount! Sorry You cannot purchase this truck");
			this.displayCustomerMenu(theCustomer.getName(), theInventory, theCustomer);
		}
	}

	/**
	 * This method is used to get the data of the price and display all the trucks which are 
	 * under that price. If there are not any found, then an appropriate message should be displayed
	 * @param theInventory This holds the object reference of the truck inventory class
	 * @param theCustomer This holds the object reference of the customer class
	 */
	private void viewTrucksUnderPrice(TruckInventory theInventory, Customer theCustomer) {
		System.out.println("Please enter a price: ");
		String inputPrice = this.keyboard.nextLine();
		double price = Double.parseDouble(inputPrice);
		
		Locale usa = new Locale("en", "US");
		NumberFormat dollarFormat = NumberFormat.getCurrencyInstance(usa);
		ArrayList<Truck> listOfTrucksUnderPrice = theInventory.findTrucksUnder(price);
		
		if (listOfTrucksUnderPrice.size() == 0) {
			System.out.println("Sorry, no trucks are available for price " + dollarFormat.format(price) + " in the inventory");
		} else {
			System.out.println("The trucks which are under the price " + dollarFormat.format(price) + " are:");
			System.out.printf("\n%-15s %-10s %-15s %-1s\n", "Manufacturer", "Torque", "Price", "Customer Satisfaction");
			for (Truck truck : listOfTrucksUnderPrice) {
				truck.getFormattedDescription();
			}
		}
		this.displayCustomerMenu(theCustomer.getName(), theInventory, theCustomer);
	}
}
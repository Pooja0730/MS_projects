# 1. This Project is event organizer application named Evento

# 2. Bootstrap elements used

-> carousel slide
-> row

let menu = document.querySelector("#menu-bars");
let navbar = document.querySelector(".my-navbar");

menu.onclick = () => {
    menu.classList.toggle("fa-times");
    navbar.classList.toggle("active");
}

window.onscroll = () => {
    menu.classList.toggle("fa-times");
    navbar.classList.toggle("active");
}

document.querySelectorAll(".theme-btn").forEach(btn => {

    btn.onclick = () => {
        let color = btn.style.background;
        document.querySelector(":root").style.setProperty('--main-color',color);
    }
});

var swiper = new Swiper(".review-slider", {
    slidesPerView: 1,
    grabCursor: true,
    loop: true,
    spaceBetween: 10,
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        700: {
            slidesPerView: 2,
        },
        1050: {
            slidesPerView: 3,
        },
    },
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    }
});

let add_to_act_btns = document.getElementsByClassName("party-btn");
let main_container = document.getElementsByTagName("tbody")[0];
let remove_btns = document.getElementsByClassName("remove-item-btn");

for(let i = 0; i < add_to_act_btns.length; i++) {
    add_to_act_btns[i].addEventListener("click", addToCart);
}

function addToCart(event) {
    let btn = event.target;
    let btn_parent = btn.parentElement;
    let btn_grandparent = btn.parentElement.parentElement.parentElement;

    let itemName =  btn_parent.children[0].innerText;
    let itemPrice = btn_parent.children[1].innerText;

    let itemContainer = document.createElement("tr");
    itemContainer.innerHTML = `
                                <td class="uk-text-truncate"></td>
                                <td class="uk-table-link">
                                    <h3 class="item-name">${itemName}</h3>
                                </td>
                                <td class="uk-text-truncate"></td>
                                <td class="uk-text-truncate"></td>
                                <td class="uk-text-truncate"></td>
                                <td class="uk-text-truncate item-price"><h3>${itemPrice}</h3></td>
                                <td><button class="uk-button uk-button-danger btn remove-item-btn" type="button">Remove</button></td>
                                <td class="uk-text-truncate"></td>
                             `;
    
    main_container.append(itemContainer);
    
    for(let i = 0; i < remove_btns.length; i++) {
        remove_btns[i].addEventListener("click", removeItem);
    }

    grandTotal();
}

function grandTotal() {
    let total = 0;
    let grand_total = document.getElementsByClassName("grand-total")[0];
    let item_price = document.getElementsByClassName("item-price");
    for(let i = 0; i < item_price.length; i++) {
        total_price_content = Number(item_price[i].innerText.replace("$", ""));
        total += total_price_content;
    }
    grand_total.children[0].innerText = "$" + total;
    grand_total.children[0].style.fontWeight = " bold";
    console.log(total);
}

function removeItem(event) {
    remove_btn = event.target;
    remove_btn_grandparent = remove_btn.parentElement.parentElement;
    remove_btn_grandparent.remove();
    grandTotal();
}
/**
 * Script to process the submitted form data of the form in file
 * pricing.html 
 */

document.getElementById('num-activities').addEventListener('focusout', validateActivitiesInput);
document.getElementById('check-checkbox').addEventListener('focusout', validateServiceTypeChecks);
document.getElementById('price-button').addEventListener('click', calculateTotal);

/**
 * This function validates the number of activites input field. This field accepts any number greater than 0  
 */
function validateActivitiesInput() {
    let numOfActivities = document.getElementById('num-activities');

    if (numOfActivities.value <= 0) {
        document.getElementById('activities-error').classList.remove('display-none');
    } else {
        document.getElementById('activities-error').classList.add('display-none');
    }
    document.getElementById('price-result').classList.add('display-none');
}

/**
 * This function validates the 3 checkbox fields. It allows any one of the checkboxes to be checked.  
 */
function validateServiceTypeChecks() {
    let checkPremium = document.getElementById('premium');
    let checkElite = document.getElementById('elite');
    let checkDeluxe = document.getElementById('deluxe');
    
    if ((checkPremium.checked == true && checkElite.checked == true) ||
     (checkElite.checked == true && checkDeluxe.checked == true) ||
      (checkPremium.checked == true && checkDeluxe.checked == true) || 
      (checkPremium.checked == true && checkElite.checked == true && checkDeluxe.checked == true)) {
        document.getElementById('serviceType-error').classList.remove('display-none');
        return false;
    } else {
        document.getElementById('serviceType-error').classList.add('display-none');
        return true;
    }
}

/**
 * This function calculates the total price according to the number of activites as well as the type of the service selected.
 */
function calculateTotal() {
    let checkboxValidate = document.getElementById('check-checkbox').addEventListener('focusout', validateServiceTypeChecks);
    if (checkboxValidate == false) {
        document.getElementById('price-result').classList.add('display-none');

    } else {
        let numOfActivities = document.getElementById('num-activities').value;
        let checkPremium = document.getElementById('premium');
        let checkElite = document.getElementById('elite');
        let checkDeluxe = document.getElementById('deluxe');
        let tierFee = 0;
        let feeType = 10;
        let totalBeforeTax = 0;
        let taxFee = 0;
        let totalPrice = 0;
        let basicPrice = 0;

        basicPrice = numOfActivities * 100;
        document.getElementById('price-value').innerHTML = "$" + basicPrice.toFixed(2);

        if (checkPremium.checked == true) {
            tierFee = numOfActivities * feeType;
        } else if (checkElite.checked == true) {
            feeType = 20
            tierFee = numOfActivities * feeType;
        } else if (checkDeluxe.checked == true) {
            feeType = 30
            tierFee = numOfActivities * feeType;
        }


        document.getElementById('tier-value').innerHTML = "(" + numOfActivities + " x $" + feeType + ") $" + tierFee.toFixed(2);

        totalBeforeTax = basicPrice + tierFee;
        taxFee = totalBeforeTax * 0.15;

        totalPrice = totalBeforeTax + taxFee;
        document.getElementById('taxes-value').innerHTML = "$" + taxFee.toFixed(2);
        document.getElementById('total-value').innerHTML = "$" + totalPrice.toFixed(2);

        document.getElementById('price-result').classList.remove('display-none');
    }
}